package com.adarshsahu.internshalafood.model

data class RestaurantMenu(

    val id: String,
    val name: String,
    val cost_for_one: String,
    val restaurant_id: String,
)